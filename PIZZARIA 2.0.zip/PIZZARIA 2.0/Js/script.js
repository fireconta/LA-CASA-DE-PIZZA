let selectedState = '';
let selectedCity = '';
let cartItems = [];
let currentCombo = null;
let stock = {
    casal: 10,
    familia: 10,
    supremo: 5,
    calabresa: 20,
    margherita: 20,
    quatroqueijos: 20,
    frangocatupiry: 20,
    portuguesa: 20,
    chocolate: 15,
    brigadeiro: 15,
    banana: 15,
    morango: 15
};

// Função para escapar HTML
function escapeHTML(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

// Função para exibir notificações gerais
function showNotification(message, isError = false, announce = false) {
    try {
        const notification = document.getElementById('notification');
        if (!notification) throw new Error('Elemento de notificação não encontrado');
        notification.textContent = message;
        notification.classList.remove('error');
        if (isError) notification.classList.add('error');
        notification.classList.add('visible');
        if (announce) notification.setAttribute('role', 'alert');
        setTimeout(() => {
            notification.classList.remove('visible');
            notification.removeAttribute('role');
        }, 3000);
    } catch (error) {
        console.error('Erro ao exibir notificação:', error);
    }
}

// Função para exibir mensagem de erro no modal
function showModalError(message) {
    try {
        const errorMessage = document.getElementById('error-message');
        if (!errorMessage) throw new Error('Elemento error-message não encontrado');
        errorMessage.textContent = message;
        errorMessage.classList.add('visible');
        setTimeout(() => {
            errorMessage.classList.remove('visible');
        }, 5000);
    } catch (error) {
        console.error('Erro ao exibir mensagem de erro:', error);
        showNotification('Erro interno ao exibir mensagem!', true);
    }
}

// Carregar estados via API do IBGE
async function fetchStates() {
    try {
        const response = await fetch('https://servicodados.ibge.gov.br/api/v1/localidades/estados?orderBy=nome');
        if (!response.ok) throw new Error(`HTTP ${response.status}: Falha na requisição de estados`);
        const states = await response.json();
        const stateSelect = document.getElementById('state');
        if (!stateSelect) throw new Error('Elemento state-select não encontrado');
        stateSelect.innerHTML = '<option value="">Selecione um estado</option>';
        states.forEach(state => {
            const option = document.createElement('option');
            option.value = state.id;
            option.textContent = state.nome;
            stateSelect.appendChild(option);
        });
    } catch (error) {
        console.error('Erro ao carregar estados:', error);
        showModalError('Erro ao carregar estados. Tente novamente.');
        showNotification('Erro ao carregar estados!', true);
    }
}

// Carregar cidades via API do IBGE
async function fetchCities(stateId) {
    try {
        const response = await fetch(`https://servicodados.ibge.gov.br/api/v1/localidades/estados/${stateId}/municipios?orderBy=nome`);
        if (!response.ok) throw new Error(`HTTP ${response.status}: Falha na requisição de cidades`);
        const cities = await response.json();
        const citySelect = document.getElementById('city');
        if (!citySelect) throw new Error('Elemento city-select não encontrado');
        citySelect.innerHTML = '<option value="">Selecione uma cidade</option>';
        cities.forEach(city => {
            const option = document.createElement('option');
            option.value = city.nome;
            option.textContent = city.nome;
            citySelect.appendChild(option);
        });
        citySelect.disabled = false;
        citySelect.focus();
    } catch (error) {
        console.error('Erro ao carregar cidades:', error);
        showModalError('Erro ao carregar cidades. Tente novamente.');
        showNotification('Erro ao carregar cidades!', true);
    }
}

// Exibir modal de localização
function showLocationModal() {
    try {
        if (!localStorage.getItem('locationSelected')) {
            const modal = document.getElementById('location-modal');
            const overlay = document.getElementById('modal-overlay');
            if (!modal || !overlay) throw new Error('Elementos do modal de localização não encontrados');
            modal.classList.add('active');
            overlay.classList.add('active');
            modal.setAttribute('aria-hidden', 'false');
            overlay.setAttribute('aria-hidden', 'false');
            fetchStates();
        } else {
            updateLocation();
            showMenu();
        }
    } catch (error) {
        console.error('Erro ao exibir modal de localização:', error);
        showNotification('Erro ao abrir modal de localização!', true);
    }
}

// Selecionar estado
function selectState() {
    try {
        const stateSelect = document.getElementById('state');
        if (!stateSelect) throw new Error('Elemento state-select não encontrado');
        if (!stateSelect.value) {
            showModalError('Por favor, selecione um estado.');
            return;
        }
        selectedState = stateSelect.options[stateSelect.selectedIndex].text;
        fetchCities(stateSelect.value);
        document.getElementById('state-step').classList.remove('active');
        document.getElementById('city-step').classList.add('active');
        document.getElementById('error-message').classList.remove('visible');
    } catch (error) {
        console.error('Erro ao selecionar estado:', error);
        showModalError('Erro ao selecionar estado.');
        showNotification('Erro ao selecionar estado!', true);
    }
}

// Selecionar cidade
function selectCity() {
    try {
        const citySelect = document.getElementById('city');
        if (!citySelect) throw new Error('Elemento city-select não encontrado');
        if (!citySelect.value) {
            showModalError('Por favor, selecione uma cidade.');
            return;
        }
        selectedCity = citySelect.value;
        document.getElementById('city-step').classList.remove('active');
        document.getElementById('searching-step').classList.add('active');
        document.getElementById('error-message').classList.remove('visible');
        setTimeout(() => {
            document.getElementById('searching-step').classList.remove('active');
            document.getElementById('store-info').textContent = `Loja mais próxima em ${escapeHTML(selectedCity)} encontrada a 1,6 km`;
            document.getElementById('store-found-step').classList.add('active');
        }, 5000);
    } catch (error) {
        console.error('Erro ao selecionar cidade:', error);
        showModalError('Erro ao selecionar cidade.');
        showNotification('Erro ao selecionar cidade!', true);
    }
}

// Confirmar loja encontrada
function confirmStore() {
    try {
        localStorage.setItem('locationSelected', 'true');
        const modal = document.getElementById('location-modal');
        const overlay = document.getElementById('modal-overlay');
        if (!modal || !overlay) throw new Error('Elementos do modal de localização não encontrados');
        modal.classList.remove('active');
        overlay.classList.remove('active');
        modal.setAttribute('aria-hidden', 'true');
        overlay.setAttribute('aria-hidden', 'true');
        updateLocation();
        showMenu();
        const firstAddButton = document.querySelector('.add-to-cart');
        if (firstAddButton) firstAddButton.focus();
    } catch (error) {
        console.error('Erro ao confirmar loja:', error);
        showModalError('Erro ao confirmar loja.');
        showNotification('Erro ao confirmar loja!', true);
    }
}

// Atualizar localização no cabeçalho
function updateLocation() {
    try {
        const locationElement = document.getElementById('location');
        if (!locationElement) throw new Error('Elemento location não encontrado');
        locationElement.textContent = `📍 ${escapeHTML(selectedCity)}, ${escapeHTML(selectedState)} • ~1,6km de você`;
    } catch (error) {
        console.error('Erro ao atualizar localização:', error);
        showNotification('Erro ao atualizar localização!', true);
    }
}

// Exibir menu
function showMenu() {
    try {
        document.querySelectorAll('.menu-section').forEach(section => {
            section.classList.add('active');
        });
    } catch (error) {
        console.error('Erro ao exibir menu:', error);
        showNotification('Erro ao exibir menu!', true);
    }
}

// Fechar modal de localização
function closeLocationModal() {
    try {
        const modal = document.getElementById('location-modal');
        const overlay = document.getElementById('modal-overlay');
        if (!modal || !overlay) throw new Error('Elementos do modal de localização não encontrados');
        modal.classList.remove('active');
        overlay.classList.remove('active');
        modal.setAttribute('aria-hidden', 'true');
        overlay.setAttribute('aria-hidden', 'true');
        document.getElementById('state').focus();
        document.getElementById('error-message').classList.remove('visible');
    } catch (error) {
        console.error('Erro ao fechar modal de localização:', error);
        showNotification('Erro ao fechar modal de localização!', true);
    }
}

// Funções do carrinho
function addToCart(button) {
    try {
        if (!localStorage.getItem('locationSelected')) {
            showNotification('Selecione sua localização primeiro!', true);
            showLocationModal();
            return;
        }
        const stockKey = button.dataset.comboStock || button.dataset.itemStock;
        if (stock[stockKey] <= 0) {
            showNotification('Item fora de estoque!', true);
            return;
        }
        button.classList.add('loading');
        button.disabled = true;
        setTimeout(() => {
            button.classList.remove('loading');
            button.disabled = false;
            if (button.dataset.comboName) {
                currentCombo = {
                    name: button.dataset.comboName,
                    price: parseFloat(button.dataset.comboPrice),
                    stockKey: button.dataset.comboStock,
                    traditionalCount: parseInt(button.dataset.comboTraditional || 0),
                    sweetCount: parseInt(button.dataset.comboSweet || 0)
                };
                openFlavorModal();
            } else {
                const item = {
                    id: Date.now(),
                    name: button.dataset.itemName,
                    price: parseFloat(button.dataset.itemPrice),
                    quantity: 1,
                    stockKey: button.dataset.itemStock
                };
                const existingItem = cartItems.find(i => i.name === item.name);
                if (existingItem) {
                    existingItem.quantity++;
                } else {
                    cartItems.push(item);
                }
                stock[stockKey]--;
                updateStockDisplay(stockKey);
                updateCartDisplay();
                showNotification(`${item.name} adicionado ao carrinho!`);
            }
        }, 1000);
    } catch (error) {
        console.error('Erro ao adicionar ao carrinho:', error);
        button.classList.remove('loading');
        button.disabled = false;
        showNotification('Erro ao adicionar ao carrinho!', true);
    }
}

function openFlavorModal() {
    try {
        if (!currentCombo) return;
        const modal = document.getElementById('flavor-modal');
        const overlay = document.getElementById('modal-overlay');
        const selections = document.getElementById('flavor-selections');
        if (!modal || !overlay || !selections) throw new Error('Elementos do modal de sabores não encontrados');
        selections.innerHTML = '';
        const traditionalFlavors = [
            { name: 'Calabresa', img: 'images/pizza-calabresa.jpg' },
            { name: 'Margherita', img: 'images/pizza-margherita.jpg' },
            { name: 'Quatro Queijos', img: 'images/pizza-quatroqueijos.jpg' },
            { name: 'Frango com Catupiry', img: 'images/pizza-frangocatupiry.jpg' },
            { name: 'Portuguesa', img: 'images/pizza-portuguesa.jpg' }
        ];
        const sweetFlavors = [
            { name: 'Chocolate', img: 'images/pizza-chocolate.jpg' },
            { name: 'Brigadeiro', img: 'images/pizza-brigadeiro.jpg' },
            { name: 'Banana com Canela', img: 'images/pizza-banana.jpg' },
            { name: 'Morango com Chocolate', img: 'images/pizza-morango.jpg' }
        ];
        let selectedFlavors = new Set();
        for (let i = 0; i < currentCombo.traditionalCount; i++) {
            const heading = document.createElement('h3');
            heading.textContent = `Pizza Tradicional ${i + 1}`;
            heading.style.color = '#dc2626';
            heading.style.marginBottom = '1rem';
            selections.appendChild(heading);
            traditionalFlavors.forEach(flavor => {
                const card = document.createElement('div');
                card.className = 'flavor-card';
                card.innerHTML = `
                    <img src="${flavor.img}" alt="Imagem da ${flavor.name}">
                    <h3>${flavor.name}</h3>
                    <p>${flavor.name === 'Calabresa' ? 'Calabresa fatiada, cebola, muçarela' : 
                        flavor.name === 'Margherita' ? 'Molho de tomate, muçarela, manjericão' : 
                        flavor.name === 'Quatro Queijos' ? 'Muçarela, parmesão, provolone, gorgonzola' : 
                        flavor.name === 'Frango com Catupiry' ? 'Frango, catupiry, muçarela, milho' : 
                        'Presunto, muçarela, ovo, cebola, azeitona'}</p>
                    <button onclick="selectFlavor(this, '${flavor.name}', 'traditional')">Selecionar</button>
                `;
                selections.appendChild(card);
            });
        }
        for (let i = 0; i < currentCombo.sweetCount; i++) {
            const heading = document.createElement('h3');
            heading.textContent = `Pizza Doce ${i + 1}`;
            heading.style.color = '#dc2626';
            heading.style.marginBottom = '1rem';
            selections.appendChild(heading);
            sweetFlavors.forEach(flavor => {
                const card = document.createElement('div');
                card.className = 'flavor-card';
                card.innerHTML = `
                    <img src="${flavor.img}" alt="Imagem da ${flavor.name}">
                    <h3>${flavor.name}</h3>
                    <p>${flavor.name === 'Chocolate' ? 'Chocolate ao leite com granulado' : 
                        flavor.name === 'Brigadeiro' ? 'Brigadeiro cremoso com granulado' : 
                        flavor.name === 'Banana com Canela' ? 'Banana fatiada com canela' : 
                        'Morangos frescos com chocolate'}</p>
                    <button onclick="selectFlavor(this, '${flavor.name}', 'sweet')">Selecionar</button>
                `;
                selections.appendChild(card);
            });
        }
        modal.classList.add('active');
        overlay.classList.add('active');
        modal.setAttribute('aria-hidden', 'false');
        overlay.setAttribute('aria-hidden', 'false');
        window.selectedFlavors = selectedFlavors;
    } catch (error) {
        console.error('Erro ao abrir modal de sabores:', error);
        showNotification('Erro ao abrir modal de sabores!', true);
    }
}

function selectFlavor(button, flavor, type) {
    try {
        const card = button.parentElement;
        const needed = type === 'traditional' ? currentCombo.traditionalCount : currentCombo.sweetCount;
        const selected = Array.from(card.parentElement.querySelectorAll('.selected')).length;
        if (card.classList.contains('selected')) {
            card.classList.remove('selected');
            window.selectedFlavors.delete(flavor);
            button.disabled = false;
            button.textContent = 'Selecionar';
        } else if (selected < needed) {
            card.classList.add('selected');
            window.selectedFlavors.add(flavor);
            button.disabled = true;
            button.textContent = 'Selecionado';
        } else {
            showNotification(`Apenas ${needed} ${type === 'traditional' ? 'tradicional' : 'doce'} permitido!`, true);
        }
    } catch (error) {
        console.error('Erro ao selecionar sabor:', error);
        showNotification('Erro ao selecionar sabor!', true);
    }
}

function confirmFlavors() {
    try {
        const flavors = Array.from(window.selectedFlavors);
        if (flavors.length !== (currentCombo.traditionalCount + currentCombo.sweetCount)) {
            showNotification('Selecione todos os sabores!', true);
            return;
        }
        const item = {
            id: Date.now(),
            name: currentCombo.name,
            price: currentCombo.price,
            quantity: 1,
            stockKey: currentCombo.stockKey,
            flavors
        };
        cartItems.push(item);
        stock[currentCombo.stockKey]--;
        updateStockDisplay(currentCombo.stockKey);
        updateCartDisplay();
        showNotification(`${currentCombo.name} adicionado ao carrinho!`);
        closeFlavorModal();
        currentCombo = null;
    } catch (error) {
        console.error('Erro ao confirmar sabores:', error);
        showNotification('Erro ao confirmar sabores!', true);
    }
}

function closeFlavorModal() {
    try {
        const modal = document.getElementById('flavor-modal');
        const overlay = document.getElementById('modal-overlay');
        if (!modal || !overlay) throw new Error('Elementos do modal de sabores não encontrados');
        modal.classList.remove('active');
        overlay.classList.remove('active');
        modal.setAttribute('aria-hidden', 'true');
        overlay.setAttribute('aria-hidden', 'true');
        currentCombo = null;
    } catch (error) {
        console.error('Erro ao fechar modal de sabores:', error);
        showNotification('Erro ao fechar modal de sabores!', true);
    }
}

function updateQuantity(id, change) {
    try {
        const item = cartItems.find(i => i.id === id);
        if (!item) return;
        if (change > 0 && stock[item.stockKey] <= 0) {
            showNotification('Item fora de estoque!', true);
            return;
        }
        item.quantity += change;
        if (change > 0) {
            stock[item.stockKey]--;
        } else {
            stock[item.stockKey]++;
        }
        if (item.quantity <= 0) {
            cartItems = cartItems.filter(i => i.id !== id);
        }
        updateStockDisplay(item.stockKey);
        updateCartDisplay();
    } catch (error) {
        console.error('Erro ao atualizar quantidade:', error);
        showNotification('Erro ao atualizar quantidade!', true);
    }
}

function removeFromCart(id) {
    try {
        const item = cartItems.find(i => i.id === id);
        if (!item) return;
        stock[item.stockKey] += item.quantity;
        cartItems = cartItems.filter(i => i.id !== id);
        updateStockDisplay(item.stockKey);
        updateCartDisplay();
        showNotification(`${item.name} removido do carrinho!`);
    } catch (error) {
        console.error('Erro ao remover do carrinho:', error);
        showNotification('Erro ao remover do carrinho!', true);
    }
}

function updateStockDisplay(stockKey) {
    try {
        const stockElement = document.getElementById(`stock-${stockKey}`);
        if (stockElement) {
            stockElement.textContent = `Restam ${stock[stockKey]} unidades`;
        }
        const button = document.querySelector(`[data-combo-stock="${stockKey}"], [data-item-stock="${stockKey}"]`);
        if (button) {
            button.disabled = stock[stockKey] <= 0;
        }
    } catch (error) {
        console.error('Erro ao atualizar estoque:', error);
    }
}

function updateCartDisplay() {
    try {
        const cartItemsDiv = document.getElementById('cart-items');
        const cartTotalDiv = document.getElementById('cart-total');
        const cartCountSpan = document.getElementById('cart-count');
        const checkoutBtn = document.getElementById('checkout-btn');
        if (!cartItemsDiv || !cartTotalDiv || !cartCountSpan || !checkoutBtn) {
            throw new Error('Elementos do carrinho não encontrados');
        }
        cartItemsDiv.innerHTML = '';
        let total = 0;
        let itemCount = 0;
        cartItems.forEach(item => {
            total += item.price * item.quantity;
            itemCount += item.quantity;
            const itemDiv = document.createElement('div');
            itemDiv.className = 'cart-item';
            itemDiv.innerHTML = `
                <div class="cart-item-details">
                    <span>${escapeHTML(item.name)}</span>
                    ${item.flavors ? `<span>Sabores: ${escapeHTML(item.flavors.join(', '))}</span>` : ''}
                    <span>R$ ${(item.price * item.quantity).toFixed(2)}</span>
                </div>
                <div class="quantity-controls">
                    <button class="quantity-btn" onclick="updateQuantity(${item.id}, -1)">-</button>
                    <span>${item.quantity}</span>
                    <button class="quantity-btn" onclick="updateQuantity(${item.id}, 1)">+</button>
                    <button class="remove-from-cart" onclick="removeFromCart(${item.id})">Remover</button>
                </div>
            `;
            cartItemsDiv.appendChild(itemDiv);
        });
        cartTotalDiv.textContent = `Total: R$ ${total.toFixed(2)}`;
        cartCountSpan.textContent = itemCount;
        const minimumMessage = document.getElementById('minimum-order-message');
        minimumMessage.classList.toggle('visible', total < 10 && itemCount > 0);
        checkoutBtn.disabled = itemCount === 0;
    } catch (error) {
        console.error('Erro ao atualizar carrinho:', error);
        showNotification('Erro ao atualizar carrinho!', true);
    }
}

function toggleCart() {
    try {
        const cart = document.getElementById('cart');
        if (!cart) throw new Error('Elemento cart não encontrado');
        cart.classList.toggle('active');
        cart.setAttribute('aria-hidden', !cart.classList.contains('active'));
    } catch (error) {
        console.error('Erro ao alternar carrinho:', error);
        showNotification('Erro ao abrir/fechar carrinho!', true);
    }
}

function openConfirmClearModal() {
    try {
        if (cartItems.length === 0) {
            showNotification('O carrinho já está vazio!', true);
            return;
        }
        const modal = document.getElementById('confirm-clear-modal');
        const overlay = document.getElementById('modal-overlay');
        if (!modal || !overlay) throw new Error('Elementos do modal de confirmação não encontrados');
        modal.classList.add('active');
        overlay.classList.add('active');
        modal.setAttribute('aria-hidden', 'false');
        overlay.setAttribute('aria-hidden', 'false');
    } catch (error) {
        console.error('Erro ao abrir modal de confirmação:', error);
        showNotification('Erro ao abrir modal de confirmação!', true);
    }
}

function closeConfirmClearModal() {
    try {
        const modal = document.getElementById('confirm-clear-modal');
        const overlay = document.getElementById('modal-overlay');
        if (!modal || !overlay) throw new Error('Elementos do modal de confirmação não encontrados');
        modal.classList.remove('active');
        overlay.classList.remove('active');
        modal.setAttribute('aria-hidden', 'true');
        overlay.setAttribute('aria-hidden', 'true');
    } catch (error) {
        console.error('Erro ao fechar modal de confirmação:', error);
        showNotification('Erro ao fechar modal de confirmação!', true);
    }
}

function confirmClearCart() {
    try {
        cartItems.forEach(item => {
            stock[item.stockKey] += item.quantity;
            updateStockDisplay(item.stockKey);
        });
        cartItems = [];
        updateCartDisplay();
        closeConfirmClearModal();
        showNotification('Carrinho limpo com sucesso!');
    } catch (error) {
        console.error('Erro ao limpar carrinho:', error);
        showNotification('Erro ao limpar carrinho!', true);
    }
}

function openCheckoutModal() {
    try {
        if (!localStorage.getItem('locationSelected')) {
            showNotification('Selecione sua localização primeiro!', true);
            showLocationModal();
            return;
        }
        if (cartItems.length === 0) {
            showNotification('Seu carrinho está vazio!', true);
            return;
        }
        const total = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        if (total < 10) {
            showNotification('O pedido mínimo é R$ 10,00!', true);
            return;
        }
        const modal = document.getElementById('checkout-modal');
        const overlay = document.getElementById('modal-overlay');
        if (!modal || !overlay) throw new Error('Elementos do modal de checkout não encontrados');
        modal.classList.add('active');
        overlay.classList.add('active');
        modal.setAttribute('aria-hidden', 'false');
        overlay.setAttribute('aria-hidden', 'false');
    } catch (error) {
        console.error('Erro ao abrir modal de checkout:', error);
        showNotification('Erro ao abrir checkout!', true);
    }
}

function closeCheckoutModal() {
    try {
        const modal = document.getElementById('checkout-modal');
        const overlay = document.getElementById('modal-overlay');
        if (!modal || !overlay) throw new Error('Elementos do modal de checkout não encontrados');
        modal.classList.remove('active');
        overlay.classList.remove('active');
        modal.setAttribute('aria-hidden', 'true');
        overlay.setAttribute('aria-hidden', 'true');
    } catch (error) {
        console.error('Erro ao fechar modal de checkout:', error);
        showNotification('Erro ao fechar checkout!', true);
    }
}

function confirmCheckout() {
    try {
        const name = document.getElementById('name').value.trim();
        const address = document.getElementById('address').value.trim();
        const phone = document.getElementById('phone').value.trim();
        if (!name || !address || !phone) {
            showNotification('Por favor, preencha todos os campos!', true);
            return;
        }
        const total = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const orderItems = cartItems.map(item => {
            let description = `${item.quantity}x ${item.name}`;
            if (item.flavors) {
                description += ` (${item.flavors.join(', ')})`;
            }
            return description;
        }).join('\n');
        const message = encodeURIComponent(`Gostaria de fazer um pedido!!\n${orderItems}\nValor do pedido: R$ ${total.toFixed(2)}`);
        window.location.href = `https://wa.me/+5562995771104?text=${message}`;
        closeCheckoutModal();
        document.getElementById('confirmation-page').classList.add('active');
        document.querySelectorAll('.menu-section').forEach(section => section.classList.remove('active'));
        document.getElementById('confirmation-details').innerHTML = `
            <p><strong>Nome:</strong> ${escapeHTML(name)}</p>
            <p><strong>Endereço:</strong> ${escapeHTML(address)}</p>
            <p><strong>Telefone:</strong> ${escapeHTML(phone)}</p>
            <p><strong>Itens:</strong> ${orderItems.replace(/\n/g, '<br>')}</p>
            <p><strong>Total:</strong> R$ ${total.toFixed(2)}</p>
        `;
    } catch (error) {
        console.error('Erro ao confirmar checkout:', error);
        showNotification('Erro ao finalizar pedido!', true);
    }
}

function backToMenu() {
    try {
        document.getElementById('confirmation-page').classList.remove('active');
        showMenu();
    } catch (error) {
        console.error('Erro ao voltar ao menu:', error);
        showNotification('Erro ao voltar ao menu!', true);
    }
}

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
    showLocationModal();
    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', () => addToCart(button));
    });
    document.getElementById('cart-toggle-btn').addEventListener('click', toggleCart);
});